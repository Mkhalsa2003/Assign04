/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bankaccount;

/**
 *
 * @author student
 */
import javax.swing.JOptionPane;

import java.util.Scanner;

public class BankAccount{
    
    
    public static void main(String[] args){
       
        String Number = JOptionPane.showInputDialog( "What is your Bank Number?");
       int s=  Integer.parseInt(Number);
       setNumber(s);
        
        BankAccount account  = new BankAccount(100);
        account.deposit(500);
        account.withdraw(50);
        JOptionPane.showMessageDialog(null, account.getNumber());
        System.out.println("Bank Number: " + account.getNumber());
        System.out.println("Balance: " + account.getBalance());
        
    }
    private double balance;
    private static int accountNumber;
    Scanner input = new Scanner (System.in);
    
 
    
    public BankAccount(double initialBalance)
    {
        balance = initialBalance;
       
    }
    public void deposit(double depositAmount)
    {
        balance += depositAmount;
        
    }
    public boolean withdraw(double withdrawAmount)
    {
        if (withdrawAmount>balance){
            System.out.println("Insufficinet Balance!");
            return false;
        }
        else {
            balance -= withdrawAmount;
            return true;
        }
    }
    public int getNumber()
    {
 
        return accountNumber;
    }
    public static void setNumber(int s ){
        
        accountNumber = s;
        
    }
    public double getBalance()
    {
        return balance;
    }
   
}
