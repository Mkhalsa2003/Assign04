/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankaccount;

/**
 *
 * @author student
 */
public class SavingsAccount extends BankAccount{
    
    private boolean active;
    double annualR;
    double balance = getNumber();
    
    public SavingsAccount(double balance){
        super(balance);
        if (balance <25){
            active = false;}
        else{
            System.out.println("Not Active");
        } 
    }
    public void Withdraw(double amount){
        super.withdraw(amount);
    }
    
    public void calcInterest(){
        double monthR = annualR/12;
        double monthBal = monthR * balance;
        balance += monthBal;
        
    }
    public void setAnnualR(double R){
       annualR = R;
    }
    
}
