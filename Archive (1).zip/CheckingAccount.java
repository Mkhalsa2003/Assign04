/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankaccount;

/**
 *
 * @author student
 */
public class CheckingAccount extends BankAccount{
    double insufficientFundsFee;
    double amount;
    

    public CheckingAccount(double balance ){
        super(balance);
        if (balance < 10){
            System.out.println("Not enough balance");
        }
        else{
            System.out.println("balance:");
        }
        
    }
    public void Withdraw(){
        super.withdraw(amount);
    }
    public void processCheck(double CheckVal){
        super.deposit(CheckVal);
    
}
    
    
}
